window.onscroll = function () {
        var theta = document.documentElement.scrollTop / 50 % Math.PI;

        document.getElementById('rotate').style.transform = 'rotate(' + theta + 'rad)';
}

$(function () {
        var rotation = 0,
                scrollLoc = $(document).scrollTop();
        $(window).scroll(function () {
                var newLoc = $(document).scrollTop();
                var diff = scrollLoc - newLoc;
                rotation += diff, scrollLoc = newLoc;
                var rotationStr = "rotate(" + rotation + "deg)";
                $("rotate").css({
                        "-webkit-transform": rotationStr,
                        "-moz-transform": rotationStr,
                        "transform": rotationStr
                });
        });
})
