


function conti(){
   if(document.getElementById("limit").checked ){
      document.getElementById("ct").disabled=false;
      document.getElementById("ct").style.display="inline";
   }
   else{
      alert("please tick the box");
      document.getElementById("ct").disabled=true;
      
   }
    
}

/*function show(){
   document.getElementById("rinfo").style.display = "flex";
   document.getElementById("finfo").style.display = "none";
   document.getElementById("rinfo").disabled=true;
   document.getElementById("finfo").disabled=false;

}


<input type="checkbox" id="limit2" onclick="conti()">

&& document.getElementById("limit2").onclick*/

      /*if(document.getElementById("ct").onclick){
         window.location.href = "thank.html";
      }*/