

function conti(){
    if(document.getElementById("limit").checked ){
       document.getElementById("ct").disabled=false;
       document.getElementById("ct").style.display="inline";
    }
    else{
       alert("please agree the Terms and Conditions");
       document.getElementById("ct").disabled=true;
       
    }
     
 }