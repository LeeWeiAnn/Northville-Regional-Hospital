function conti() {
   if (document.getElementById("agree").checked) {
      document.getElementById("rbtn").disabled = false;
      document.getElementById("rbtn").style.display = "inline";
   }
   else {
      alert("Please agree the Terms and Conditions");
      document.getElementById("rbtn").disabled = true;

   }

}